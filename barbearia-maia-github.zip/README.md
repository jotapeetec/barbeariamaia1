# 💈 Barbearia Maia

Site institucional, catálogo de produtos e sistema de agendamento com carrinho interativo desenvolvido para a **Barbearia Maia**.

## ✨ Funcionalidades

- **Design Responsivo & Tema Dark/Gold:** Interface moderna adaptada para celulares, tablets e desktops.
- **Menu de Serviços & Agendamento:** Seleção de cortes e barboterapia com escolha automática de data e horário no carrinho.
- **Catálogo de Produtos com Filtros:** Filtragem dinâmica por categoria (*Todos, Cabelo, Barba, Kits*).
- **Carrinho Interativo (LocalStorage):** Adição, remoção, alteração de quantidades, persistência automática no navegador e aplicação de cupom de desconto (`MAIA10`).

## 🚀 Como publicar no GitHub Pages

1. Crie um novo repositório no GitHub (ex.: `barbearia-maia`).
2. Envie os arquivos `index.html` e `README.md` para a branch `main`.
3. Acesse **Settings > Pages** no repositório.
4. Em **Source**, selecione **Deploy from a branch**, escolha `main` / `/ (root)` e clique em **Save**.
5. Em instantes o site estará no ar no endereço `https://seu-usuario.github.io/barbearia-maia/`.
